
// import init from './examples/绘制单个点';
// import init from './examples/动态绘制点'
// import init from './examples/绘制多个点'
// import init from './examples/绘制三角形和多边形'
// import init from './examples/旋转'
// import init from './examples/单点纹理'
// import init from './examples/多重纹理'
// import init from './examples/cocos-shader前置知识'
// import init from './examples/cocos-shader前置知识纹理'
import init from './examples/时钟动画实践'
init()